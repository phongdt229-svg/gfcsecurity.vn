<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>
<section class="container gfc-404">
	<h1>404</h1>
	<p>Trang bạn tìm không tồn tại hoặc đã được chuyển.</p>
	<a class="gfc-btn gfc-btn--blue" href="<?php echo esc_url( home_url( '/' ) ); ?>">Về trang chủ</a>
</section>
<?php get_footer();
