<?php if ( ! defined( 'ABSPATH' ) ) exit;
$sw  = gfc_opt( 'switchboard' );
$h1  = gfc_opt( 'hotline1' );
$h2  = gfc_opt( 'hotline2' );
$em  = gfc_opt( 'email' );
?>
</main>

<footer class="gfc-footer">
	<div class="container gfc-footer__grid">
		<div class="gfc-footer__col gfc-footer__info">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="gfc-footer__logo"><img src="<?php echo esc_url( gfc_logo_url() ); ?>" alt="GFC Security" width="210" height="60" loading="lazy"></a>
			<h3 class="gfc-footer__title">Liên lạc</h3>
			<ul class="gfc-footer__list">
				<li>Tổng đài toàn quốc: <a href="<?php echo esc_attr( gfc_tel( $sw ) ); ?>"><?php echo esc_html( $sw ); ?></a></li>
				<li>Hotline 24/7: <a href="<?php echo esc_attr( gfc_tel( $h1 ) ); ?>"><?php echo esc_html( $h1 ); ?></a></li>
				<?php if ( $h2 ) : ?><li>Hotline 24/7: <a href="<?php echo esc_attr( gfc_tel( $h2 ) ); ?>"><?php echo esc_html( $h2 ); ?></a></li><?php endif; ?>
				<li>Email: <a href="mailto:<?php echo esc_attr( $em ); ?>"><?php echo esc_html( $em ); ?></a></li>
				<li>Mã số thuế: <?php echo esc_html( gfc_opt( 'tax' ) ); ?></li>
			</ul>
			<?php foreach ( gfc_offices() as $o ) : ?>
				<h3 class="gfc-footer__title"><?php echo esc_html( $o[0] ); ?></h3>
				<ul class="gfc-footer__list">
					<li>Địa chỉ: <?php echo esc_html( $o[1] ); ?></li>
					<li>Hotline: <a href="<?php echo esc_attr( gfc_tel( $o[2] ) ); ?>"><?php echo esc_html( $o[2] ); ?></a></li>
				</ul>
			<?php endforeach; ?>
		</div>

		<div class="gfc-footer__col">
			<h3 class="gfc-footer__title">Dịch vụ</h3>
			<?php gfc_simple_menu( 'footer_services', gfc_footer_services_default() ); ?>
		</div>

		<div class="gfc-footer__col">
			<h3 class="gfc-footer__title">Hỗ trợ khách hàng</h3>
			<?php gfc_simple_menu( 'footer_support', gfc_footer_support_default() ); ?>
			<h3 class="gfc-footer__title">Kết nối với chúng tôi</h3>
			<div class="gfc-social">
				<?php if ( gfc_opt( 'facebook' ) ) : ?><a href="<?php echo esc_url( gfc_opt( 'facebook' ) ); ?>" target="_blank" rel="noopener" aria-label="Facebook"><img src="<?php echo esc_url( gfc_up( '2025/10/image-7-1.png' ) ); ?>" alt="" width="40" height="40" loading="lazy"></a><?php endif; ?>
				<?php if ( gfc_opt( 'zalo' ) ) : ?><a href="<?php echo esc_url( gfc_opt( 'zalo' ) ); ?>" target="_blank" rel="noopener" aria-label="Zalo"><img src="<?php echo esc_url( gfc_up( '2025/10/sm-672c066b31fd3-Zalo-1-1.png' ) ); ?>" alt="" width="40" height="40" loading="lazy"></a><?php endif; ?>
				<a href="<?php echo esc_url( gfc_opt( 'youtube' ) ? gfc_opt( 'youtube' ) : '#' ); ?>" target="_blank" rel="noopener" aria-label="YouTube"><img src="<?php echo esc_url( gfc_up( '2025/10/Frame-2.png' ) ); ?>" alt="" width="40" height="40" loading="lazy"></a>
				<a href="mailto:<?php echo esc_attr( $em ); ?>" aria-label="Email"><img src="<?php echo esc_url( gfc_up( '2025/10/Frame-1-1.png' ) ); ?>" alt="" width="40" height="40" loading="lazy"></a>
			</div>
			<div class="gfc-badges">
				<a href="https://www.dmca.com/Protection/Status.aspx?ID=92301f59-1437-465c-82dd-02f987f4423a" target="_blank" rel="noopener" title="DMCA.com Protection Status"><img src="https://images.dmca.com/Badges/dmca-badge-w250-2x1-04.png?ID=92301f59-1437-465c-82dd-02f987f4423a" alt="DMCA.com Protection Status" width="125" height="62" loading="lazy"></a>
				<img src="<?php echo esc_url( gfc_up( '2025/11/BCT-LOGO-1.svg' ) ); ?>" alt="Đã thông báo Bộ Công Thương" width="180" height="62" loading="lazy">
			</div>
		</div>

		<div class="gfc-footer__col">
			<h3 class="gfc-footer__title">Hệ sinh thái</h3>
			<div class="gfc-eco">
				<img src="<?php echo esc_url( gfc_up( '2025/10/1.svg' ) ); ?>" alt="" loading="lazy">
				<img src="<?php echo esc_url( gfc_up( '2025/10/image-1896.svg' ) ); ?>" alt="" loading="lazy">
				<img src="<?php echo esc_url( gfc_up( '2025/10/image-1895.svg' ) ); ?>" alt="" loading="lazy">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( gfc_up( '2025/11/GFCsecurity-1.png' ) ); ?>" alt="GFC Security" loading="lazy"></a>
			</div>
			<h3 class="gfc-footer__title">Thành viên của</h3>
			<div class="gfc-eco"><img src="<?php echo esc_url( gfc_up( '2025/10/image-1899.svg' ) ); ?>" alt="GFC Group" loading="lazy"></div>
		</div>
	</div>
	<div class="container gfc-footer__copy"><?php echo esc_html( gfc_opt( 'copyright' ) ); ?></div>
</footer>

<div class="gfc-float" aria-label="Liên hệ nhanh">
	<a class="is-blue" href="<?php echo esc_url( gfc_opt( 'zalo' ) ); ?>" target="_blank" rel="noopener"><img src="<?php echo esc_url( gfc_up( '2025/10/svg_zalo_icon-1.svg' ) ); ?>" alt="" width="28" height="28"><span>Nhắn tin Zalo</span></a>
	<a class="is-green" href="<?php echo esc_url( gfc_link( gfc_opt( 'hire_url' ) ) ); ?>"><img src="<?php echo esc_url( gfc_up( '2025/10/Frame-1171277672.svg' ) ); ?>" alt="" width="28" height="28"><span>Thuê bảo vệ</span></a>
	<a class="is-blue" href="<?php echo esc_url( gfc_link( gfc_opt( 'jobs_url' ) ) ); ?>"><img src="<?php echo esc_url( gfc_up( '2025/10/Frame-1171277672-1.svg' ) ); ?>" alt="" width="28" height="28"><span>Tìm việc bảo vệ</span></a>
	<a class="is-green" href="<?php echo esc_attr( gfc_tel( $h1 ) ); ?>"><img src="<?php echo esc_url( gfc_up( '2025/10/Frame-1171277672-2.svg' ) ); ?>" alt="" width="28" height="28"><span>Hotline: <?php echo esc_html( preg_replace( '/[^0-9]/', '', $h1 ) ); ?></span></a>
	<a class="is-blue" href="<?php echo esc_attr( gfc_tel( $sw ) ); ?>"><img src="<?php echo esc_url( gfc_up( '2025/10/Frame-1171277672-3.svg' ) ); ?>" alt="" width="28" height="28"><span>Tổng đài: <?php echo esc_html( $sw ); ?></span></a>
</div>

<?php wp_footer(); ?>
</body>
</html>
