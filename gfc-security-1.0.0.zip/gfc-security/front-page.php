<?php
/** Trang chủ */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
$d = gfc_home_data();
$h = $d['hero'];
?>

<!-- HERO -->
<section class="gfc-hero" style="background-image:url('<?php echo esc_url( $h['bg'] ); ?>')">
	<div class="gfc-hero__media">
		<div class="swiper js-hero">
			<div class="swiper-wrapper">
				<?php foreach ( $h['slides'] as $i => $src ) : ?>
					<div class="swiper-slide"><img src="<?php echo esc_url( $src ); ?>" alt="Công ty dịch vụ bảo vệ GFC Security" <?php echo $i ? 'loading="lazy"' : 'fetchpriority="high"'; ?>></div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<div class="container gfc-hero__in">
		<div class="gfc-hero__text">
			<h1><?php echo wp_kses( $h['title'], array( 'br' => array() ) ); ?></h1>
			<p class="gfc-hero__sub"><?php echo esc_html( $h['subtitle'] ); ?></p>
			<ul class="gfc-hero__pills">
				<?php foreach ( $h['features'] as $f ) : ?>
					<li><img src="<?php echo esc_url( $f[0] ); ?>" alt="" width="22" height="22"><span><?php echo esc_html( $f[1] ); ?></span></li>
				<?php endforeach; ?>
			</ul>
			<a class="gfc-btn gfc-btn--green" href="<?php echo esc_url( $h['cta_url'] ); ?>"><?php echo gfc_icon( 'call' ); // phpcs:ignore ?> <?php echo esc_html( $h['cta_text'] ); ?></a>
		</div>
	</div>
</section>

<!-- GIỚI THIỆU -->
<section class="gfc-intro">
	<div class="container gfc-intro__grid">
		<div class="gfc-intro__text">
			<?php foreach ( $d['intro']['paragraphs'] as $p ) : ?>
				<p><?php echo esc_html( $p ); ?></p>
			<?php endforeach; ?>
			<a class="gfc-btn gfc-btn--blue" href="<?php echo esc_url( gfc_opt( 'profile_url' ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $d['intro']['btn_text'] ); ?></a>
		</div>
		<div class="gfc-intro__video">
			<span class="deco deco--green"></span><span class="deco deco--blue"></span>
			<button class="gfc-yt" type="button" data-yt="<?php echo esc_attr( $d['intro']['youtube'] ); ?>" aria-label="Phát video giới thiệu">
				<img src="https://i.ytimg.com/vi/<?php echo esc_attr( $d['intro']['youtube'] ); ?>/hqdefault.jpg" alt="Giới thiệu Tập đoàn bảo vệ GFC Security" loading="lazy">
				<span class="gfc-yt__play"><?php echo gfc_icon( 'play' ); // phpcs:ignore ?></span>
			</button>
		</div>
	</div>
</section>

<!-- SỐ LIỆU + DỊCH VỤ -->
<section class="gfc-services">
	<div class="container">
		<div class="gfc-stats">
			<?php foreach ( $d['stats'] as $s ) : ?>
				<div class="gfc-stats__item">
					<span class="gfc-stats__label"><?php echo esc_html( $s[0] ); ?></span>
					<strong class="gfc-stats__num"><span class="js-count" data-to="<?php echo esc_attr( $s[1] ); ?>"><?php echo esc_html( $s[1] >= 10000 ? number_format( $s[1], 0, ',', '.' ) : $s[1] ); ?></span><?php echo esc_html( $s[2] ); ?></strong>
				</div>
			<?php endforeach; ?>
		</div>

		<h2 class="gfc-title gfc-title--left"><?php echo wp_kses( $d['services_title'], array( 'span' => array() ) ); ?></h2>
		<div class="gfc-svc-grid">
			<?php foreach ( $d['services'] as $i => $s ) : ?>
				<a class="gfc-svc<?php echo ( 0 === $i || count( $d['services'] ) - 1 === $i ) ? ' is-wide' : ''; ?>" href="<?php echo esc_url( gfc_link( $s[1] ) ); ?>" style="background-image:linear-gradient(rgba(27,29,31,0) 0%,rgba(27,29,31,.5) 100%),url('<?php echo esc_url( gfc_up( $s[2] ) ); ?>')">
					<h3><?php echo esc_html( $s[0] ); ?></h3>
					<span class="gfc-svc__more">Xem chi tiết</span>
				</a>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<!-- ĐIỂM KHÁC BIỆT -->
<section class="gfc-diff" style="background-image:url('<?php echo esc_url( $d['diff']['bg'] ); ?>')">
	<div class="container">
		<h2 class="gfc-title gfc-title--white"><?php echo esc_html( $d['diff']['title'] ); ?></h2>
		<p class="gfc-diff__desc"><?php echo esc_html( $d['diff']['desc'] ); ?></p>
		<div class="gfc-diff__grid">
			<?php foreach ( $d['diff']['items'] as $it ) : ?>
				<div class="gfc-diff__card">
					<span class="gfc-diff__ic"><?php echo gfc_icon( $it[0] ); // phpcs:ignore ?></span>
					<div><h3><?php echo esc_html( $it[1] ); ?></h3><p><?php echo esc_html( $it[2] ); ?></p></div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<!-- CHỨNG NHẬN -->
<section class="gfc-sec gfc-awards">
	<div class="container">
		<h2 class="gfc-title"><?php echo esc_html( $d['awards_title'] ); ?></h2>
		<div class="gfc-slider">
			<button class="gfc-arrow gfc-arrow--prev js-awards-prev" type="button" aria-label="Trước"><?php echo gfc_icon( 'prev' ); // phpcs:ignore ?></button>
			<div class="swiper js-awards">
				<div class="swiper-wrapper">
					<?php foreach ( $d['awards'] as $a ) : ?>
						<div class="swiper-slide"><img src="<?php echo esc_url( gfc_up( $a ) ); ?>" alt="Chứng nhận giải thưởng công ty bảo vệ GFC" loading="lazy"></div>
					<?php endforeach; ?>
				</div>
			</div>
			<button class="gfc-arrow gfc-arrow--next js-awards-next" type="button" aria-label="Sau"><?php echo gfc_icon( 'next' ); // phpcs:ignore ?></button>
		</div>
	</div>
</section>

<!-- KHÁCH HÀNG -->
<section class="gfc-sec gfc-clients">
	<div class="container"><h2 class="gfc-title"><?php echo esc_html( $d['clients_title'] ); ?></h2></div>
	<?php foreach ( array( 'clients_row1' => '', 'clients_row2' => ' is-reverse' ) as $row => $cls ) : ?>
		<div class="gfc-marquee<?php echo esc_attr( $cls ); ?>">
			<div class="gfc-marquee__track">
				<?php for ( $k = 0; $k < 2; $k++ ) : foreach ( $d[ $row ] as $logo ) : ?>
					<span class="gfc-logo-card"><img src="<?php echo esc_url( gfc_up( $logo ) ); ?>" alt="Khách hàng của GFC Security" decoding="async" <?php echo $k ? 'aria-hidden="true"' : ''; ?>></span>
				<?php endforeach; endfor; ?>
			</div>
		</div>
	<?php endforeach; ?>
</section>

<!-- CHI NHÁNH -->
<section class="gfc-sec gfc-branches">
	<div class="container">
		<h2 class="gfc-title"><?php echo wp_kses( $d['branches_title'], array( 'br' => array() ) ); ?></h2>
		<div class="gfc-branches__grid">
			<div class="gfc-branches__map">
				<h3>Trụ sở chính và 2 chi nhánh Hà Nội, Đà Nẵng</h3>
				<img src="<?php echo esc_url( $d['branches_map'] ); ?>" alt="Bản đồ hệ thống chi nhánh GFC Security" loading="lazy">
			</div>
			<div class="gfc-branches__list">
				<p class="gfc-branches__count"><?php echo esc_html( $d['branches_count'] ); ?></p>
				<ul>
					<?php foreach ( gfc_get_branches() as $b ) : ?>
						<li>
							<span class="pin"><?php echo gfc_icon( 'pin' ); // phpcs:ignore ?></span>
							<div>
								<?php if ( $b['url'] ) : ?><a href="<?php echo esc_url( $b['url'] ); ?>"><strong><?php echo esc_html( $b['name'] ); ?></strong></a><?php else : ?><strong><?php echo esc_html( $b['name'] ); ?></strong><?php endif; ?>
								<span><?php echo esc_html( $b['address'] ); ?></span>
								<?php if ( $b['phone'] ) : ?><a href="<?php echo esc_attr( gfc_tel( $b['phone'] ) ); ?>"><?php echo esc_html( $b['phone'] ); ?></a><?php endif; ?>
							</div>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
	</div>
</section>

<!-- BÁO CHÍ -->
<section class="gfc-sec gfc-press">
	<div class="container">
		<h2 class="gfc-title"><?php echo esc_html( $d['press_title'] ); ?></h2>
		<div class="gfc-press__grid">
			<?php foreach ( $d['press'] as $p ) : ?>
				<a class="gfc-logo-card" href="<?php echo esc_url( $p[1] ? $p[1] : '#' ); ?>" <?php echo $p[1] ? 'target="_blank" rel="noopener"' : ''; ?>><img src="<?php echo esc_url( gfc_up( $p[0] ) ); ?>" alt="Báo chí viết về GFC Security" loading="lazy"></a>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<!-- FEEDBACK -->
<section class="gfc-sec gfc-feedback">
	<div class="container">
		<h2 class="gfc-title"><?php echo esc_html( $d['feedback_title'] ); ?></h2>
		<div class="gfc-slider">
			<button class="gfc-arrow gfc-arrow--prev js-fb-prev" type="button" aria-label="Trước"><?php echo gfc_icon( 'prev' ); // phpcs:ignore ?></button>
			<div class="swiper js-fb">
				<div class="swiper-wrapper">
					<?php foreach ( $d['feedback'] as $f ) : ?>
						<div class="swiper-slide">
							<div class="gfc-review">
								<div class="gfc-review__head">
									<img src="<?php echo esc_url( gfc_up( $f[0] ) ); ?>" alt="Feedback khách hàng GFC Security" width="44" height="44" loading="lazy">
									<div><strong><?php echo esc_html( $f[1] ); ?></strong><span>1 bài đánh giá</span></div>
								</div>
								<div class="gfc-stars" aria-label="5 sao">★★★★★</div>
								<p><?php echo esc_html( $f[2] ); ?></p>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<button class="gfc-arrow gfc-arrow--next js-fb-next" type="button" aria-label="Sau"><?php echo gfc_icon( 'next' ); // phpcs:ignore ?></button>
		</div>
	</div>
</section>

<!-- KIẾN THỨC -->
<?php
$cat   = get_category_by_slug( $d['blog_category'] );
$posts = new WP_Query( array(
	'posts_per_page'      => 4,
	'ignore_sticky_posts' => true,
	'cat'                 => $cat ? $cat->term_id : 0,
) );
if ( $posts->have_posts() ) : ?>
<section class="gfc-sec gfc-blog">
	<div class="container">
		<h2 class="gfc-title gfc-title--left"><?php echo esc_html( $d['blog_title'] ); ?></h2>
		<div class="gfc-posts">
			<?php while ( $posts->have_posts() ) : $posts->the_post(); get_template_part( 'template-parts/card' ); endwhile; wp_reset_postdata(); ?>
		</div>
		<div class="gfc-center"><a class="gfc-btn gfc-btn--outline" href="<?php echo esc_url( $cat ? get_category_link( $cat ) : home_url( '/tin-tuc' ) ); ?>">Xem tất cả</a></div>
	</div>
</section>
<?php endif; ?>

<!-- FAQ -->
<section class="gfc-sec gfc-faq">
	<div class="container">
		<h2 class="gfc-title gfc-title--left"><?php echo esc_html( $d['faq_title'] ); ?></h2>
		<div class="gfc-faq__grid">
			<div class="gfc-faq__img"><img src="<?php echo esc_url( $d['faq_image'] ); ?>" alt="Công ty bảo vệ cung cấp dịch vụ bảo vệ chuyên nghiệp" loading="lazy"></div>
			<div class="gfc-acc">
				<?php foreach ( $d['faq'] as $i => $q ) : ?>
					<details class="gfc-acc__item" <?php echo 0 === $i ? 'open' : ''; ?>>
						<summary><?php echo esc_html( ( $i + 1 ) . '. ' . $q[0] ); ?><?php echo gfc_icon( 'chevron' ); // phpcs:ignore ?></summary>
						<div class="gfc-acc__body"><?php echo wp_kses_post( $q[1] ); ?></div>
					</details>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>

<?php
// FAQ schema cho SEO
$faq_ld = array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array() );
foreach ( $d['faq'] as $q ) {
	$faq_ld['mainEntity'][] = array( '@type' => 'Question', 'name' => $q[0], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => wp_strip_all_tags( $q[1] ) ) );
}
echo '<script type="application/ld+json">' . wp_json_encode( $faq_ld, JSON_UNESCAPED_UNICODE ) . '</script>';

get_footer();
