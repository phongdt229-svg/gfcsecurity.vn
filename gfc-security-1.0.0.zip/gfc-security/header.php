<?php if ( ! defined( 'ABSPATH' ) ) exit; ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Bỏ qua đến nội dung</a>
<header class="gfc-header" id="top">
	<div class="container gfc-header__in">
		<a class="gfc-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
			<img src="<?php echo esc_url( gfc_logo_url() ); ?>" alt="GFC Security" width="210" height="60">
		</a>
		<button class="gfc-burger" type="button" aria-label="Mở menu" aria-expanded="false" aria-controls="gfc-nav"><?php echo gfc_icon( 'menu' ); // phpcs:ignore ?></button>
		<nav class="gfc-nav" id="gfc-nav" aria-label="Menu chính">
			<button class="gfc-nav__close" type="button" aria-label="Đóng menu"><?php echo gfc_icon( 'close' ); // phpcs:ignore ?></button>
			<?php gfc_primary_menu(); ?>
		</nav>
	</div>
</header>
<div class="gfc-overlay" hidden></div>
<main id="main" class="gfc-main">
