<?php
/** Danh sách bài viết / danh mục tin tức / tìm kiếm */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
if ( is_search() ) {
	$title = 'Kết quả tìm kiếm: ' . get_search_query();
} elseif ( is_archive() ) {
	$title = wp_strip_all_tags( get_the_archive_title() );
} else {
	$title = 'Tin tức';
}
$title = preg_replace( '/^(Danh mục|Category):\s*/u', '', $title );
?>
<div class="container gfc-pt">
	<div class="gfc-breadcrumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Trang chủ</a> <span class="sep">›</span> <span><?php echo esc_html( $title ); ?></span></div>
	<h1 class="gfc-title gfc-title--left"><?php echo esc_html( $title ); ?></h1>
	<?php if ( is_category() && category_description() ) : ?><div class="gfc-archive-desc"><?php echo wp_kses_post( category_description() ); ?></div><?php endif; ?>
	<?php if ( have_posts() ) : ?>
		<div class="gfc-posts">
			<?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/card' ); endwhile; ?>
		</div>
		<nav class="gfc-pagination"><?php echo wp_kses_post( paginate_links( array( 'prev_text' => '‹', 'next_text' => '›' ) ) ); ?></nav>
	<?php else : ?>
		<p>Chưa có bài viết.</p>
	<?php endif; ?>
</div>
<?php get_footer();
