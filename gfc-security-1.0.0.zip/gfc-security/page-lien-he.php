<?php
/**
 * Trang Liên hệ (tự áp dụng cho trang có đường dẫn /lien-he).
 * Cũng có thể chọn thủ công: Mẫu trang → "Trang liên hệ GFC".
 *
 * Template Name: Trang liên hệ GFC
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
$sw = gfc_opt( 'switchboard' );
$h1 = gfc_opt( 'hotline1' );
$em = gfc_opt( 'email' );
$banner = has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'full' ) : gfc_up( '2025/10/Rectangle-1-1-scaled.png' );
?>
<section class="gfc-cbanner"><img src="<?php echo esc_url( $banner ); ?>" alt="Liên hệ GFC Security" fetchpriority="high"></section>
<div class="container"><?php gfc_breadcrumb(); ?></div>

<section class="container gfc-ssec">
	<h1 class="gfc-title">Thông tin liên hệ</h1>
	<div class="gfc-cinfo">
		<a class="gfc-cinfo__card" href="<?php echo esc_attr( gfc_tel( $sw ) ); ?>"><img src="<?php echo esc_url( gfc_up( '2025/11/Frame-3.svg' ) ); ?>" alt="" width="40" height="40"><span>Tổng đài toàn quốc<strong><?php echo esc_html( $sw ); ?></strong></span></a>
		<a class="gfc-cinfo__card" href="<?php echo esc_attr( gfc_tel( $h1 ) ); ?>"><img src="<?php echo esc_url( gfc_up( '2025/11/Frame-1-1.svg' ) ); ?>" alt="" width="40" height="40"><span>Hotline 24/7<strong><?php echo esc_html( str_replace( '.', ' ', $h1 ) ); ?></strong></span></a>
		<a class="gfc-cinfo__card" href="mailto:<?php echo esc_attr( $em ); ?>"><img src="<?php echo esc_url( gfc_up( '2025/11/Frame-2-1.svg' ) ); ?>" alt="" width="40" height="40"><span>Email<strong><?php echo esc_html( $em ); ?></strong></span></a>
	</div>

	<div class="gfc-offices">
		<div class="gfc-offices__list">
			<?php foreach ( gfc_offices() as $o ) : ?>
				<div class="gfc-office">
					<h3><?php echo esc_html( $o[0] ); ?></h3>
					<p><?php echo gfc_icon( 'pin' ); // phpcs:ignore ?><span><strong>Địa chỉ:</strong> <?php echo esc_html( $o[1] ); ?></span></p>
					<p><?php echo gfc_icon( 'call' ); // phpcs:ignore ?><span><strong>Số điện thoại:</strong> <a href="<?php echo esc_attr( gfc_tel( $o[2] ) ); ?>"><?php echo esc_html( $o[2] ); ?></a></span></p>
				</div>
			<?php endforeach; ?>
		</div>
		<div class="gfc-offices__map">
			<iframe title="Bản đồ trụ sở GFC Security" src="https://www.google.com/maps?q=<?php echo rawurlencode( gfc_opt( 'map_query' ) ); ?>&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
		</div>
	</div>
</section>

<section class="container gfc-ssec gfc-cform">
	<div class="gfc-cform__img"><img src="<?php echo esc_url( gfc_up( '2025/10/image-1.png' ) ); ?>" alt="Nhân viên bảo vệ GFC Security" loading="lazy"></div>
	<div class="gfc-cform__box">
		<h2>Gửi ngay yêu cầu của bạn cho chúng tôi!</h2>
		<p>Chúng tôi luôn sẵn sàng lắng nghe &amp; phản hồi yêu cầu của bạn nhanh nhất có thể.</p>
		<?php
		$cf7 = absint( gfc_opt( 'cf7_id' ) );
		if ( $cf7 && shortcode_exists( 'contact-form-7' ) ) {
			echo do_shortcode( '[contact-form-7 id="' . $cf7 . '"]' );
		} else {
			get_template_part( 'template-parts/contact-form' );
		}
		?>
	</div>
</section>

<?php
while ( have_posts() ) : the_post();
	if ( '' !== trim( get_the_content() ) ) {
		echo '<section class="container gfc-ssec"><div class="gfc-content entry-content">';
		the_content();
		echo '</div></section>';
	}
endwhile;
get_footer();
