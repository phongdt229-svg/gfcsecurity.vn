<?php
/**
 * Template Name: Trang dịch vụ GFC
 * Template Post Type: page
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
while ( have_posts() ) : the_post();
	$hero_img = gfc_smeta( 'hero_image' );
	if ( ! $hero_img && has_post_thumbnail() ) $hero_img = get_the_post_thumbnail_url( null, 'full' );
	get_template_part( 'template-parts/page-hero', null, array(
		'title' => get_the_title(),
		'desc'  => gfc_smeta( 'hero_desc' ) ? gfc_smeta( 'hero_desc' ) : get_the_excerpt(),
		'image' => $hero_img,
	) );
	?>
	<div class="container"><?php gfc_breadcrumb(); ?></div>

	<?php $rows = gfc_lines( gfc_smeta( 'price_rows' ) ); if ( $rows ) : $head = gfc_lines( gfc_smeta( 'price_head' ) ); ?>
	<section class="container gfc-ssec">
		<h2 class="gfc-stitle"><?php echo esc_html( gfc_smeta( 'price_title' ) ); ?></h2>
		<div class="gfc-table-wrap">
			<table class="gfc-table">
				<thead><tr><th><?php echo esc_html( $head ? $head[0][0] : 'Loại dịch vụ' ); ?></th><th><?php echo esc_html( $head ? $head[0][1] : 'Bảng giá (VNĐ)' ); ?></th></tr></thead>
				<tbody><?php foreach ( $rows as $r ) : ?><tr><td><?php echo esc_html( $r[0] ); ?></td><td><?php echo esc_html( $r[1] ); ?></td></tr><?php endforeach; ?></tbody>
			</table>
		</div>
		<?php $notes = gfc_lines( gfc_smeta( 'price_notes' ), 1 ); if ( $notes ) : ?>
			<div class="gfc-notes"><strong><em>*Lưu ý:</em></strong>
				<?php foreach ( $notes as $n ) : ?><div>– <?php echo esc_html( $n[0] ); ?></div><?php endforeach; ?>
			</div>
		<?php endif; ?>
	</section>
	<?php endif; ?>

	<?php if ( gfc_smeta( 'adv_image' ) ) : ?>
	<section class="container gfc-ssec">
		<h2 class="gfc-stitle"><?php echo esc_html( gfc_smeta( 'adv_title' ) ); ?></h2>
		<img class="gfc-infographic" src="<?php echo esc_url( gfc_link( gfc_smeta( 'adv_image' ) ) ); ?>" alt="<?php echo esc_attr( gfc_smeta( 'adv_title' ) ); ?>" loading="lazy">
	</section>
	<?php endif; ?>

	<?php $tasks = gfc_lines( gfc_smeta( 'tasks' ) ); if ( $tasks ) : ?>
	<section class="gfc-tasks">
		<div class="container">
			<h2 class="gfc-stitle"><?php echo esc_html( gfc_smeta( 'tasks_title' ) ); ?></h2>
			<div class="gfc-tasks__grid">
				<div class="gfc-tasks__imgs">
					<?php if ( gfc_smeta( 'tasks_img1' ) ) : ?><img class="img1" src="<?php echo esc_url( gfc_link( gfc_smeta( 'tasks_img1' ) ) ); ?>" alt="Nhân viên bảo vệ GFC Security" loading="lazy"><?php endif; ?>
					<?php if ( gfc_smeta( 'tasks_img2' ) ) : ?><img class="img2" src="<?php echo esc_url( gfc_link( gfc_smeta( 'tasks_img2' ) ) ); ?>" alt="Nhân viên bảo vệ GFC Security" loading="lazy"><?php endif; ?>
				</div>
				<ul class="gfc-tasks__list">
					<?php foreach ( $tasks as $t ) : ?>
						<li><h3><?php echo gfc_icon( 'guard' ); // phpcs:ignore ?><?php echo esc_html( $t[0] ); ?></h3><p><?php echo esc_html( $t[1] ); ?></p></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( gfc_smeta( 'process_title' ) ) : ?>
	<section class="container gfc-ssec">
		<h2 class="gfc-stitle"><?php echo esc_html( gfc_smeta( 'process_title' ) ); ?></h2>
		<?php if ( gfc_smeta( 'process_desc' ) ) : ?><p><?php echo esc_html( gfc_smeta( 'process_desc' ) ); ?></p><?php endif; ?>
		<?php if ( gfc_smeta( 'process_image' ) ) : ?><img class="gfc-infographic" src="<?php echo esc_url( gfc_link( gfc_smeta( 'process_image' ) ) ); ?>" alt="<?php echo esc_attr( gfc_smeta( 'process_title' ) ); ?>" loading="lazy"><?php endif; ?>
	</section>
	<?php endif; ?>

	<?php if ( gfc_smeta( 'std_title' ) ) : ?>
	<section class="container gfc-ssec">
		<h2 class="gfc-stitle"><?php echo esc_html( gfc_smeta( 'std_title' ) ); ?></h2>
		<?php if ( gfc_smeta( 'std_desc' ) ) : ?><p><?php echo esc_html( gfc_smeta( 'std_desc' ) ); ?></p><?php endif; ?>
		<?php if ( gfc_smeta( 'std_link_url' ) ) : ?><p><a class="gfc-link" href="<?php echo esc_url( gfc_link( gfc_smeta( 'std_link_url' ) ) ); ?>"><?php echo esc_html( gfc_smeta( 'std_link_text' ) ? gfc_smeta( 'std_link_text' ) : 'Xem chi tiết' ); ?></a></p><?php endif; ?>
	</section>
	<?php endif; ?>

	<?php if ( '' !== trim( get_the_content() ) ) : ?>
	<section class="container gfc-ssec">
		<div class="gfc-content entry-content"><?php the_content(); ?></div>
	</section>
	<?php endif; ?>
<?php endwhile;
get_footer();
