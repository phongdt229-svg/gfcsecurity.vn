<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
while ( have_posts() ) : the_post();
	get_template_part( 'template-parts/page-hero', null, array(
		'title' => get_the_title(),
		'desc'  => has_excerpt() ? get_the_excerpt() : '',
		'image' => has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'full' ) : '',
	) ); ?>
	<div class="container"><?php gfc_breadcrumb(); ?></div>
	<section class="container gfc-ssec">
		<div class="gfc-content entry-content"><?php the_content(); ?></div>
	</section>
<?php endwhile;
get_footer();
