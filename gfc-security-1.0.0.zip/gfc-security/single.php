<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
while ( have_posts() ) : the_post(); ?>
	<div class="container gfc-pt"><?php gfc_breadcrumb(); ?></div>
	<div class="container gfc-single">
		<article class="gfc-single__main">
			<h1 class="gfc-single__title"><?php the_title(); ?></h1>
			<div class="gfc-single__meta"><?php echo gfc_icon( 'calendar' ); // phpcs:ignore ?> <?php echo esc_html( get_the_date( 'd/m/Y' ) ); ?> · <?php the_category( ', ' ); ?></div>
			<div class="gfc-content entry-content"><?php the_content(); ?></div>
		</article>
		<aside class="gfc-single__side">
			<div class="gfc-side-cta">
				<h3>Cần tư vấn dịch vụ bảo vệ?</h3>
				<p>Gọi ngay để được khảo sát và báo giá miễn phí.</p>
				<a class="gfc-btn gfc-btn--green" href="<?php echo esc_attr( gfc_tel( gfc_opt( 'hotline1' ) ) ); ?>"><?php echo gfc_icon( 'call' ); // phpcs:ignore ?> <?php echo esc_html( gfc_opt( 'hotline1' ) ); ?></a>
			</div>
			<?php
			$rel = new WP_Query( array( 'posts_per_page' => 5, 'post__not_in' => array( get_the_ID() ), 'category__in' => wp_get_post_categories( get_the_ID() ), 'ignore_sticky_posts' => true ) );
			if ( $rel->have_posts() ) : ?>
				<div class="gfc-side-list"><h3>Bài viết liên quan</h3><ul>
				<?php while ( $rel->have_posts() ) : $rel->the_post(); ?><li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li><?php endwhile; wp_reset_postdata(); ?>
				</ul></div>
			<?php endif; ?>
		</aside>
	</div>
<?php endwhile;
get_footer();
